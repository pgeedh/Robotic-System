// this #ifndef stops this file
// from being included mored than
// once by the compiler.
#ifndef _KINEMATICS_H
#define _KINEMATICS_H

long count_new_r = 0;
long count_new_l = 0;

float x = 0;
float y = 0;
float theta = 0;
float home_angle = 0;

#define PI 3.1415926535897932384626433832795
// Class to track robot position.

float Distance_factor = (2 * PI * 1.6) / 358.3;
class Kinematics_c
{
public:
  // Constructor, must exist.
  Kinematics_c()
  {
  }

  // Use this function to update
  // your kinematics
  void update()
  {
    long count_diff_r = count_e0 - count_new_r;
    long count_diff_l = count_e1 - count_new_l;
    count_new_r = count_e0;
    count_new_l = count_e1;

    float d_r = count_diff_r * Distance_factor;
    float d_l = count_diff_l * Distance_factor;

    float d = (d_r + d_l) / 2;

    float delta_theta = (d_r - d_l) / 9.2;

    x = x + (d * cos(theta));
    y = y + (d * sin(theta));
    theta = theta + delta_theta;

    if (theta > 2.0 * PI)
      theta -= 2.0 * PI;
    if (theta < 0.0)
      theta += 2.0 * PI;
  }

  void calculate_home_angle()
  {
    home_angle = atan2(y, x);
    if (home_angle > 2.0 * PI)
      home_angle -= 2.0 * PI;
    if (home_angle < 0.0)
      home_angle += 2.0 * PI;

    home_angle = 3.14 + home_angle + 0.4835;

    if (home_angle > 2.0 * PI)
      home_angle -= 2.0 * PI;
    if (home_angle < 0.0)
      home_angle += 2.0 * PI;
  }
};

#endif
