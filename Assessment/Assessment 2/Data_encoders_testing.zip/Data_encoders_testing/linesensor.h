// this #ifndef stops this file
// from being included mored than
// once by the compiler.
#ifndef _LINESENSOR_H
#define _LINESENSOR_H

#define EMIT_PIN 11 // Documentation says 11.
#define Leftmost 12 // Complete for DN1 pin
#define Left 18
#define Middle 20
#define Right 21
#define Rightmost 22

int LS_number[5] = {Leftmost, Left, Middle, Right, Rightmost};

// Class to operate the linesensor(s).
class LineSensor_c
{
public:
  // Constructor, must exist.
  LineSensor_c()
  {
  }

  void initialise()
  {
    pinMode(EMIT_PIN, INPUT); // Set EMIT as an input (off)
    pinMode(Leftmost, INPUT); // Set line sensor pin to input
    pinMode(Left, INPUT);
    pinMode(Middle, INPUT);
    pinMode(Right, INPUT);
    pinMode(Rightmost, INPUT);
  }

  float ReadSensorData(int number)
  {
    if (number < 0)
    {
      return -99999;
    }
    if (number > 4)
    {
      return 99999;
    }

    pinMode(EMIT_PIN, OUTPUT);
    digitalWrite(EMIT_PIN, HIGH);

    pinMode(LS_number[number], OUTPUT);
    digitalWrite(LS_number[number], HIGH);
    delayMicroseconds(10);

    unsigned long start_time = micros();
    pinMode(LS_number[number], INPUT);
    while (digitalRead(LS_number[number]) == HIGH)
    {
      // Do nothing here (waiting).
    }

    unsigned long end_time = micros();

    pinMode(EMIT_PIN, INPUT);

    unsigned long elapsed_time = end_time - start_time;
    return (float)elapsed_time;
  }
};

#endif
