// this #ifndef stops this file
// from being included mored than
// once by the compiler.
#ifndef _MOTORS_H
#define _MOTORS_H

float speed = 20;
// Class to operate the motor(s).
class Motors_c
{
public:
  // Constructor, must exist.
  Motors_c()
  {
  }

  // Use this function to
  // initialise the pins and
  // state of your motor(s).
  void initialise()
  {
    pinMode(10, OUTPUT); // left motor
    pinMode(16, OUTPUT);
    pinMode(9, OUTPUT); // RIGHT motor
    pinMode(15, OUTPUT);
  }

  // Write a function to operate
  // your motor(s)
  // ...

  int L_PWM = 0;
  int R_PWM = 0;

  void Run(int LeftSpeed, int RightSpeed)
  {
    analogWrite(10, LeftSpeed);
    digitalWrite(16, LOW);
    analogWrite(9, RightSpeed);
    digitalWrite(15, LOW);

    L_PWM = LeftSpeed;
    R_PWM = RightSpeed;
  }

  void TurnRight()
  {
    analogWrite(10, 30);
    digitalWrite(16, LOW);
    analogWrite(9, 30);
    digitalWrite(15, HIGH);

    // L_PWM =
    // R_PWM = 
  }

  void STOP()
  {
    analogWrite(10, 0);
    digitalWrite(16, HIGH);
    analogWrite(9, 0);
    digitalWrite(15, HIGH);
  }

  void backward()
  {
    analogWrite(10, speed);
    digitalWrite(16, HIGH);
    analogWrite(9, speed);
    digitalWrite(15, HIGH);
  }

  void forward()
  {
    analogWrite(10, speed);
    digitalWrite(16, LOW);
    analogWrite(9, speed);
    digitalWrite(15, LOW);
  }

  void HardLeft(int LeftSpeed, int RightSpeed)
  {
    analogWrite(10, LeftSpeed);
    digitalWrite(16, HIGH);
    analogWrite(9, RightSpeed);
    digitalWrite(15, LOW);
    L_PWM = LeftSpeed* -1;
    R_PWM = RightSpeed ; 
  }

  void HardRight(int LeftSpeed, int RightSpeed)
  {
    analogWrite(10, LeftSpeed);
    digitalWrite(16, LOW);
    analogWrite(9, RightSpeed);
    digitalWrite(15, HIGH);

    L_PWM = LeftSpeed;
    R_PWM = RightSpeed * -1; 
  }
};

#endif
